<?php
include_once './model/comment.php';

// Nếu cần dữ liệu ở database thì gọi model 
$listComment = listComment();

// Xử lý xóa bình luận
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $commentId = $_GET['id'];
    deleteComment($commentId); // Gọi hàm xóa trong model
    header("Location: ?action=listcomment"); // Chuyển hướng về danh sách
    exit();
}
// Ném qua view để hiển thị cho người dùng
include_once './view/comment/index.php';

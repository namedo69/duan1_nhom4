<?php
include_once './model/comment.php';
// Xử lý xóa bình luận
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $commentId = $_GET['id'];
    deleteComment($commentId); // Gọi hàm xóa trong model
    header("Location: ?action=listcomment"); // Chuyển hướng về danh sách
    exit();
}
include_once './view/comment/index.php';

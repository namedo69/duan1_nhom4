<?php
// Nếu cần dữ liệu ở data base thì gọi model

// Xử lý dữ liệu từ database về
$income = 200000;
// Ném qua view để hiển thị cho người dùng
include_once './view/dashboard/index.php';
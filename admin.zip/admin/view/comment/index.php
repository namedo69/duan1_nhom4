<?php
include_once("./view/layouts/header.php");
?>
<div id="main">
    <div class="page-heading">
        <h3>Danh sách bình luận</h3>
        <section class="section">
            <div class="card">
                <div class="card-header">Danh sách bình luận</div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Product ID</th>
                                <th>Client ID</th>
                                <th>Nội dung</th>
                                <th>Thời gian</th>
                                <th>Hành động</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($listComment as $value): ?>
                                <tr>
                                    <td><?= $value['comment_id'] ?></td>
                                    <td><?= $value['product_id'] ?></td>
                                    <td><?= $value['client_id'] ?></td>
                                    <td><?= $value['content'] ?></td>
                                    <td><?= $value['time'] ?></td>
                                    <td>
                                        <a class="btn btn-danger"
                                           href="?action=deleteComment&id=<?= $value['comment_id'] ?>"
                                           onclick="return confirm('Bạn có chắc chắn muốn xóa?');">
                                           Xóa
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    </div>
</div>
<?php
include_once("./view/layouts/footer.php");
?>

<?php 
include_once 'pdo.php';

function listDanhMuc() {
    $sql = 'select * from category';
    return pdo_query($sql);
}
<?php

if (isset($_GET['action']) && $_GET['action'] != '') {
    $action = $_GET['action'];
    switch($action) {
    //  chức năng danh mục 
        case "listdanhmuc":
            include_once 'controller/danhmuc/index.php';
            break;
       
       
       
       
       
    //  chức năng comment
            case "listcomment":
                include_once 'controller/comment/index.php';
                break;
            case "deletecomment":
                include_once 'controller/comment/deleteComment.php';
                break;
    }
} else {
    include_once 'controller/dashboard/index.php';
}
